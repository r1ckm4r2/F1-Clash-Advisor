---
name: f1-clash-advisor
description: >
  F1 Clash game advisor that helps players optimize their car setup and upgrade strategy.
  Use this skill whenever a user mentions F1 Clash, asks about driver or component setups,
  wants to know what to upgrade next, asks which drivers to use for a track, or wants help
  building the best car loadout for a race or series. Trigger even for casual phrasing like
  "what should I upgrade in F1 Clash", "best setup for Monaco F1 Clash", or "which drivers
  should I use". Also triggers for questions about series progression, component leveling,
  or driver pairing in F1 Clash.
---

# F1 Clash Advisor

An expert advisor for F1 Clash (2026) that recommends optimal car setups and upgrade paths based on the player's current assets.

## Core Decision Priority (ALWAYS follow this order)
1. **Track stat needs** — what stats does this track demand?
2. **Components** — which components (at their current level) best cover those stats?
3. **Drivers** — which driver pair (at their current level) best complements the chosen components?

Never reverse this order. Track needs drive everything else.

## Car vs Driver Priority — CRITICAL RULE

**Car setup (components) always matters more than driver stats.** This is the single most important strategic principle in the game:

- A driver with inferior stats WINS in a well-built car setup
- A strong driver LOSES in a poorly built car setup
- Example: a Series 9 Epic driver in a well-setup car beats a Series 12 Epic driver in a bad car setup

What this means for recommendations:
- Always optimize components first — they are the foundation of every competitive setup
- Drivers complement the car, they do not compensate for a weak car
- When a player has limited upgrade resources, always prioritize components over drivers
- Lead every recommendation with the car setup and frame drivers as the finishing layer
- When a GP boost significantly strengthens a driver or component, it may justify adjusting the setup, but the car-first principle still applies

---

## Reference Files
Load these as needed:
- `references/drivers.md` — All driver stats at Level 1, organized by rarity (Common, Rare, Epic, Legendary). Load whenever a player mentions a driver. Level 2+ tables to be added as data is provided.
- `references/tracks.md` — Track stat priorities per series (all 12 series, all tracks). Load when recommending a setup for a specific track. Each track has a 1st Stat (primary) and 2nd Stat (secondary) priority — these are ranked guides, not numerical values.
- `references/components.md` — Component stat tables by name and level. Load when player provides component names and levels.

> ⚠️ Driver level 2+ tables, component tables, and track tables are pending. When data isn't available yet, tell the player: *"I don't have the full data for that yet — it's being added. Here's what I can tell you based on what's available."* Then give the best answer possible with available data.

---

## UI Trigger

When a player uses any of the following phrases (or similar intent), render the EXACT HTML artifact below — do not generate a new one, do not modify it, always use this exact code:

- "build my setup"
- "let's build my setup"
- "bring up the UI"
- "show the form"
- "setup form"
- "help me with my setup"
- "F1 Clash setup"
- Any first message asking for setup help without garage details

When the form is submitted it sends structured garage data directly into the conversation. Proceed to Step 2 with that data — do NOT ask for it again.

If the player already provided series, drivers, and components in their message, skip the UI and go straight to the recommendation.

## GARAGE FORM — RENDER THIS EXACT CODE, NEVER MODIFY IT

```html
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>F1 Clash Setup</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { padding: 1rem; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; font-size: 14px; background: #fff; color: #111; }
  .section { margin-bottom: 1.5rem; }
  .section-title { font-size: 11px; font-weight: 600; color: #888; text-transform: uppercase; letter-spacing: 0.07em; padding-bottom: 6px; margin-bottom: 10px; border-bottom: 1px solid #eee; }
  .top-row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 1.5rem; }
  .field { display: flex; flex-direction: column; gap: 4px; }
  .field-label { font-size: 12px; color: #666; }
  select { height: 34px; font-size: 13px; padding: 0 8px; border: 1px solid #ddd; border-radius: 6px; background: #fff; color: #111; width: 100%; }
  .hint { font-size: 11px; color: #999; margin-bottom: 10px; }
  .series-note { font-size: 11px; color: #999; padding: 6px 10px; background: #f7f7f7; border-radius: 6px; margin-bottom: 10px; }
  .subsection-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
  .subsection-label { font-size: 11px; font-weight: 600; color: #999; text-transform: uppercase; letter-spacing: 0.05em; }
  .uncheck-btn { font-size: 10px; padding: 2px 8px; border: 1px solid #ddd; border-radius: 10px; background: none; color: #999; cursor: pointer; }
  .uncheck-btn:hover { background: #f5f5f5; }
  .rar-tabs { display: flex; gap: 6px; margin-bottom: 8px; flex-wrap: wrap; }
  .rar-tab { font-size: 12px; padding: 4px 14px; border: 1px solid #ddd; border-radius: 20px; cursor: pointer; background: #fff; color: #666; }
  .rar-tab.active { border-color: #3b82f6; background: #eff6ff; color: #3b82f6; font-weight: 500; }
  .rar-panel { display: none; } .rar-panel.active { display: block; }
  .driver-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 5px; }
  .driver-item { display: flex; align-items: center; padding: 7px 8px; border: 1px solid #ddd; border-radius: 8px; background: #fff; cursor: pointer; user-select: none; }
  .driver-item:hover { border-color: #bbb; }
  .driver-item.checked { border-color: #3b82f6; background: #eff6ff; }
  .driver-item.store { border-style: dashed; }
  .driver-item.boosted-10 { box-shadow: 0 0 0 2px #fef3c7; border-color: #f59e0b; }
  .driver-item.boosted-20 { box-shadow: 0 0 0 2px #fee2e2; border-color: #ef4444; }
  .card-main { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }
  .driver-top { display: flex; align-items: center; gap: 5px; }
  .driver-top input[type=checkbox] { width: 13px; height: 13px; flex-shrink: 0; cursor: pointer; accent-color: #3b82f6; }
  .driver-name { font-size: 12px; font-weight: 500; color: #111; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .driver-item.checked .driver-name { color: #3b82f6; }
  .card-meta { font-size: 10px; color: #999; }
  .card-meta.store-tag { color: #f59e0b; }
  .lv-row { display: flex; align-items: center; gap: 3px; margin-top: 1px; }
  .lv-lbl { font-size: 10px; color: #999; }
  .lv-inp { width: 34px; height: 20px; font-size: 11px; padding: 0 4px; border: 1px solid #ddd; border-radius: 4px; }
  .dial-wrap { display: flex; flex-direction: column; gap: 4px; align-items: center; justify-content: center; flex-shrink: 0; padding-left: 5px; }
  .dial { width: 26px; height: 26px; border-radius: 50%; border: 1.5px solid #ddd; background: #fff; color: #999; font-size: 9px; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; user-select: none; transition: all 0.12s; }
  .dial:hover { border-color: #bbb; background: #f5f5f5; }
  .dial.on-10 { border-color: #f59e0b; background: #fef3c7; color: #d97706; box-shadow: 0 0 0 2px #fef3c7; }
  .dial.on-20 { border-color: #ef4444; background: #fee2e2; color: #dc2626; box-shadow: 0 0 0 2px #fee2e2; }
  .leg-add-row { display: flex; gap: 8px; align-items: flex-end; margin-bottom: 10px; flex-wrap: wrap; }
  .leg-add-row select { width: 160px; }
  .add-btn { height: 34px; padding: 0 14px; font-size: 12px; border: 1px solid #ddd; border-radius: 6px; background: #fff; color: #666; cursor: pointer; }
  .add-btn:hover { background: #f5f5f5; }
  .leg-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 5px; }
  .leg-item { display: flex; align-items: center; padding: 7px 8px; border: 1px solid #3b82f6; border-radius: 8px; background: #eff6ff; }
  .leg-item.boosted-10 { box-shadow: 0 0 0 2px #fef3c7; border-color: #f59e0b; }
  .leg-item.boosted-20 { box-shadow: 0 0 0 2px #fee2e2; border-color: #ef4444; }
  .leg-top { display: flex; align-items: center; justify-content: space-between; }
  .leg-name { font-size: 12px; font-weight: 500; color: #3b82f6; }
  .leg-sub { font-size: 10px; color: #999; }
  .rm-btn { font-size: 12px; color: #999; background: none; border: none; cursor: pointer; padding: 0 2px; flex-shrink: 0; }
  .rm-btn:hover { color: #ef4444; }
  .slot-block { margin-bottom: 12px; }
  .comp-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 5px; }
  .comp-item { display: flex; align-items: center; padding: 7px 8px; border: 1px solid #ddd; border-radius: 8px; background: #fff; cursor: pointer; user-select: none; }
  .comp-item:hover { border-color: #bbb; }
  .comp-item.checked { border-color: #16a34a; background: #f0fdf4; }
  .comp-item.store { border-style: dashed; }
  .comp-item.boosted-10 { box-shadow: 0 0 0 2px #fef3c7; border-color: #f59e0b; }
  .comp-item.boosted-20 { box-shadow: 0 0 0 2px #fee2e2; border-color: #ef4444; }
  .comp-cb { width: 13px; height: 13px; flex-shrink: 0; cursor: pointer; accent-color: #16a34a; margin-right: 6px; margin-top: 1px; align-self: flex-start; }
  .comp-name { font-size: 12px; color: #111; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .comp-item.checked .comp-name { color: #16a34a; font-weight: 500; }
  .boost-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 5px; }
  .boost-item { display: flex; align-items: center; gap: 6px; padding: 6px 8px; border: 1px solid #ddd; border-radius: 8px; background: #fff; cursor: pointer; user-select: none; }
  .boost-item:hover { border-color: #bbb; }
  .boost-item.checked { border-color: #f59e0b; background: #fefce8; }
  .boost-item input[type=checkbox] { width: 13px; height: 13px; flex-shrink: 0; cursor: pointer; }
  .boost-name { font-size: 12px; color: #111; }
  .boost-item.checked .boost-name { color: #d97706; font-weight: 500; }
  .boost-stat { font-size: 10px; color: #999; }
  .submit-btn { width: 100%; padding: 10px; font-size: 14px; font-weight: 500; background: #111; border: none; border-radius: 8px; cursor: pointer; color: #fff; margin-top: 8px; }
  .submit-btn:hover { background: #333; }
  .gp-legend { display: flex; gap: 12px; font-size: 11px; color: #999; margin-bottom: 8px; align-items: center; flex-wrap: wrap; }
  .dial-demo { width: 18px; height: 18px; border-radius: 50%; display:inline-flex; align-items:center; justify-content:center; font-size:8px; font-weight:700; flex-shrink:0; }
  .dial-demo.d10 { border: 1.5px solid #f59e0b; background: #fef3c7; color: #d97706; }
  .dial-demo.d20 { border: 1.5px solid #ef4444; background: #fee2e2; color: #dc2626; }
</style>
</head>
<body>
<div style="font-size:16px;font-weight:700;margin-bottom:4px">🏎️ F1 Clash Setup Builder</div>
<div style="font-size:12px;color:#888;margin-bottom:1rem">Fill in your garage and hit submit to get your recommendation.</div>

<div class="top-row">
  <div class="field"><span class="field-label">Current series</span>
    <select id="series" onchange="onSeriesChange()">
      <option value="">Select...</option>
      <option value="0">No series (use what I have)</option>
      <option>1</option><option>2</option><option>3</option><option>4</option>
      <option>5</option><option>6</option><option>7</option><option>8</option>
      <option>9</option><option>10</option><option>11</option><option>12</option>
    </select>
  </div>
  <div class="field"><span class="field-label">Specific track (optional)</span>
    <select id="track" onchange="updateBoosts()">
      <option value="">All series tracks</option>
      <option>Sao Paulo</option><option>Silverstone</option><option>Melbourne</option>
      <option>Hungaroring</option><option>Monaco</option><option>Barcelona</option>
      <option>Sakhir</option><option>Suzuka</option><option>Miami</option>
      <option>Monza</option><option>Jeddah</option><option>Las Vegas</option>
      <option>Baku</option><option>Mexico</option><option>Canada</option>
      <option>Spa</option><option>Shanghai</option><option>Zandvoort</option>
      <option>Spielberg</option><option>Austin</option><option>Singapore</option>
      <option>Abu Dhabi</option>
    </select>
  </div>
  <div class="field"><span class="field-label">What do you need?</span>
    <select id="need">
      <option value="setup">Best setup for track(s)</option>
      <option value="upgrade">Upgrade advice</option>
      <option value="both">Setup + upgrade advice</option>
    </select>
  </div>
</div>

<div id="main-content" style="display:none">
  <div class="section">
    <div class="section-title">Drivers</div>
    <div class="series-note" id="series-note"></div>
    <div class="gp-legend">
      <span>GP boost dials:</span>
      <span class="dial-demo d10">10</span><span>= +10%</span>
      <span class="dial-demo d20">20</span><span>= +20%</span>
    </div>
    <div class="rar-tabs" id="rar-tabs"></div>
    <div id="rar-panels"></div>
  </div>
  <div class="section">
    <div class="section-title">Components</div>
    <p class="hint" id="comp-hint">Solid = available by series. Dashed = future/store item.</p>
    <div id="comp-slots"></div>
  </div>
  <div class="section">
    <div class="section-title">Boosts</div>
    <p class="hint" id="boost-hint">Check the boosts you have available.</p>
    <div id="boost-container"></div>
  </div>
  <button class="submit-btn" onclick="submitForm()">Get my recommendation ↗</button>
</div>
<div id="placeholder" style="padding:2rem 0;text-align:center;color:#999;font-size:13px;">Select your series above to load your garage.</div>

<script>
const COMP_SERIES={"Front Wing":[["Wind Guard",1],["Zephyr",2],["Laminar",3],["Scythe",5],["Flashpoint",6],["Leading Edge",9],["Loose Fit",12]],"Brakes":[["Anchor",1],["Flow 2K",2],["Aegis",4],["Scramble",6],["Aura Lock",8],["Pressure Point",10],["Stabilix",12]],"Suspension":[["Shockwave",1],["Jumpstart",2],["Stability Unit",4],["Equilibrium",5],["Curver 3.0",7],["Motion Link V2",9],["Bounce",11]],"Rear Wing":[["Wobble",1],["Tailwind",2],["Air Channel",3],["Vibe Lift",5],["Impact",7],["Downforce",9],["Dominus",12]],"Gearbox":[["Cadence",1],["Flow Logic",2],["Stratos",3],["Shift X",6],["Lockdown",8],["Fracture",10],["Powerbox",11]],"Engine":[["Tempest",1],["Bedrock",3],["Velocity",5],["Axis 3000",6],["DriveOS",8],["Hotfix",10],["Overdrive",11]],"Battery":[["Charge Core",4],["Power Grid",7],["Energy Reserve",9],["Spare Pack",11]]};
const DRIVER_SERIES={"Common":[["Lindblad",1],["Colapinto",1],["Bottas",1],["Bortoleto",2],["Gasly",2],["Stroll",2],["Ocon",2],["Lawson",3],["Bearman",3],["Hadjar",3],["Hulkenberg",3],["Alonso",4],["Sainz",4],["Albon",4],["Antonelli",4],["Perez",4],["Hamilton",5],["Leclerc",5],["Russell",5],["Piastri",5],["Verstappen",5],["Norris",6]],"Rare":[["Bortoleto",1],["Bottas",2],["Colapinto",5],["Lindblad",6],["Gasly",6],["Stroll",6],["Ocon",7],["Lawson",7],["Bearman",7],["Hadjar",7],["Hulkenberg",7],["Alonso",8],["Sainz",8],["Albon",8],["Antonelli",8],["Perez",8],["Hamilton",9],["Leclerc",9],["Russell",9],["Piastri",9],["Verstappen",9],["Norris",9]],"Epic":[["Gasly",1],["Lindblad",3],["Bottas",4],["Colapinto",6],["Lawson",8],["Bortoleto",10],["Stroll",10],["Ocon",10],["Hulkenberg",10],["Albon",10],["Perez",10],["Bearman",11],["Hadjar",11],["Alonso",11],["Sainz",11],["Antonelli",11],["Hamilton",12],["Leclerc",12],["Russell",12],["Piastri",12],["Verstappen",12],["Norris",12]]};
const LEGENDARY_ALL=["Fisichella","McLaren","G.Villeneuve","Webber","Berger","Massa","Coulthard","Rindt","Hunt","J.Villeneuve","Andretti","Button","D.Hill","Mansell","G.Hill","Fittipaldi","Lauda","Brabham","Fangio","Prost","Schumacher","Senna"];
const MAX_LV={Common:11,Rare:9,Epic:8,Legendary:7};
const RARITIES=["Common","Rare","Epic"];
const BOOST_PRIMARY={"Ballast":"Race Start","Butterfly":"Power Unit","Champion":"Speed","Christmas":"Speed","Confetti":"Race Start","Cranberry":"Overtaking","Crown":"Pit Time","Cuppa":"Race Start","Dead Fast":"Speed","Djinn":"Power Unit","Downforce":"Cornering","Dragon":"Overtaking","Eagle":"Tyre Management","Eclipse":"Speed","Eggcepton":"Pit Time","Eternal Flame":"Overtaking","Feral":"Overtaking","Firework":"Speed","Frost":"Tyre Management","Full Send":"Speed","Genesis":"Defending","Ghoulfuel":"Overtaking","Gladiator":"Defending","Glitz":"Power Unit","Handlebar":"Defending","Heartbreaker":"Race Start","Herald":"Race Start","Hex":"Overtaking","Hook":"Cornering","Impact":"Overtaking","Instinct":"Power Unit","Iron Force":"Defending","Kawaii":"Cornering","Launch Pad":"Race Start","Livewire":"Tyre Management","Lumberjack":"Pit Time","Merlion":"Cornering","Midnight":"Power Unit","Movember":"Cornering","Nazar":"Tyre Management","Oud":"Overtaking","Overcharge":"Race Start","Palm":"Tyre Management","Pretzel":"Tyre Management","Prince":"Race Start","Pumpkin":"Tyre Management","Rainbow":"Defending","Reindeer":"Pit Time","Rookie Reload":"Power Unit","Rookie Rush":"Tyre Management","Rooster":"Overtaking","Samba":"Power Unit","Schooner":"Race Start","Self Control":"Cornering","Skull":"Speed","Street Shark":"Race Start","Surf":"Race Start","Taurus":"Power Unit","Timeless":"Cornering","Tire Water":"Tyre Management","Tsar":"Tyre Management","Tulip":"Speed","Tune-In":"Pit Time","Unstoppable":"Overtaking","Vice":"Defending","Warrior":"Defending"};
const TRACK_STATS={"Sao Paulo":["Overtaking","Power Unit"],"Silverstone":["Overtaking","Speed"],"Melbourne":["Race Start","Cornering"],"Hungaroring":["Overtaking","Cornering"],"Monaco":["Defending","Cornering"],"Barcelona":["Tyre Management","Speed"],"Sakhir":["Tyre Management","Power Unit"],"Suzuka":["Tyre Management","Cornering"],"Miami":["Overtaking","Speed"],"Monza":["Defending","Speed"],"Jeddah":["Defending","Speed"],"Las Vegas":["Defending","Speed"],"Baku":["Tyre Management","Power Unit"],"Mexico":["Tyre Management","Power Unit"],"Canada":["Race Start","Power Unit"],"Spa":["Overtaking","Power Unit"],"Shanghai":["Defending","Power Unit"],"Zandvoort":["Defending","Cornering"],"Spielberg":["Race Start","Cornering"],"Austin":["Race Start","Cornering"],"Singapore":["Race Start","Speed"],"Abu Dhabi":["Overtaking","Speed"]};
const SERIES_TRACKS={1:["Sao Paulo","Silverstone"],2:["Melbourne","Hungaroring","Monaco"],3:["Barcelona","Sakhir","Silverstone","Suzuka"],4:["Miami","Monza","Jeddah","Las Vegas"],5:["Baku","Mexico","Canada","Spa"],6:["Monza","Jeddah","Shanghai","Zandvoort"],7:["Melbourne","Spielberg","Austin","Singapore"],8:["Hungaroring","Abu Dhabi","Sao Paulo","Miami"],9:["Silverstone","Jeddah","Barcelona","Monza"],10:["Monaco","Zandvoort","Austin","Suzuka"],11:["Sao Paulo","Baku","Spa","Mexico"],12:["Suzuka","Silverstone","Barcelona","Sakhir"]};

function defLv(s,p){const d=p-s;if(d<0)return null;if(d===0)return 1;if(d===1)return 3;return 5;}
function makeDials(){const w=document.createElement('div');w.className='dial-wrap';['10','20'].forEach(n=>{const d=document.createElement('div');d.className='dial';d.textContent=n;d.dataset.n=n;d.title=`+${n}% GP boost`;d.onclick=e=>{e.stopPropagation();toggleDial(d);};w.appendChild(d);});return w;}
function toggleDial(dial){const n=dial.dataset.n,other=n==='10'?'20':'10';const card=dial.closest('.driver-item,.comp-item,.leg-item');const ob=dial.parentElement.querySelector(`.dial[data-n="${other}"]`);const wasOn=dial.classList.contains(`on-${n}`);dial.classList.remove(`on-${n}`);ob&&ob.classList.remove(`on-${other}`);card&&card.classList.remove(`boosted-${n}`,`boosted-${other}`);if(!wasOn){dial.classList.add(`on-${n}`);card&&card.classList.add(`boosted-${n}`);}}
function uncheckAll(gid){document.querySelectorAll(`#${gid} input[type=checkbox]`).forEach(cb=>{cb.checked=false;const c=cb.closest('.driver-item,.comp-item');if(c)c.classList.remove('checked');});}
function makeHeader(label,gid){const h=document.createElement('div');h.className='subsection-header';const l=document.createElement('span');l.className='subsection-label';l.textContent=label;const b=document.createElement('button');b.className='uncheck-btn';b.textContent='uncheck all';b.onclick=()=>uncheckAll(gid);h.appendChild(l);h.appendChild(b);return h;}

function getRelevantBoosts(){
  const track=document.getElementById('track').value;
  const series=document.getElementById('series').value;
  if(track&&TRACK_STATS[track]){
    const stats=TRACK_STATS[track];
    return Object.entries(BOOST_PRIMARY).filter(([,p])=>stats.includes(p)).map(([b])=>b).sort();
  }
  if(series&&series!=='0'){
    const s=parseInt(series);const tracks=SERIES_TRACKS[s]||[];
    const counts={};tracks.forEach(t=>{(TRACK_STATS[t]||[]).forEach(stat=>{counts[stat]=(counts[stat]||0)+1;});});
    const top2=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,2).map(([s])=>s);
    return Object.entries(BOOST_PRIMARY).filter(([,p])=>top2.includes(p)).map(([b])=>b).sort();
  }
  return Object.keys(BOOST_PRIMARY).sort();
}

function updateBoosts(){
  const boosts=getRelevantBoosts();
  const track=document.getElementById('track').value;
  const series=document.getElementById('series').value;
  const hint=document.getElementById('boost-hint');
  if(track)hint.textContent=`Boosts for ${track} (${(TRACK_STATS[track]||[]).join(' + ')}). Check what you have.`;
  else if(series&&series!=='0')hint.textContent=`Boosts relevant to Series ${series}. Check what you have.`;
  else hint.textContent='All boosts shown. Select a series or track to filter.';
  const container=document.getElementById('boost-container');container.innerHTML='';
  const grid=document.createElement('div');grid.className='boost-grid';
  boosts.forEach(name=>{
    const stat=BOOST_PRIMARY[name];
    const item=document.createElement('label');item.className='boost-item';
    const cb=document.createElement('input');cb.type='checkbox';
    cb.addEventListener('change',e=>item.classList.toggle('checked',e.target.checked));
    const left=document.createElement('div');left.style.cssText='display:flex;flex-direction:column;flex:1;min-width:0';
    const nm=document.createElement('span');nm.className='boost-name';nm.textContent=name;
    const st=document.createElement('span');st.className='boost-stat';st.textContent=stat;
    left.appendChild(nm);left.appendChild(st);item.appendChild(cb);item.appendChild(left);grid.appendChild(item);
  });
  container.appendChild(grid);
}

function onSeriesChange(){
  const s=document.getElementById('series').value;
  if(!s)return;
  document.getElementById('main-content').style.display='block';
  document.getElementById('placeholder').style.display='none';
  const noSeries=s==='0';const sNum=noSeries?null:parseInt(s);
  document.getElementById('series-note').textContent=noSeries?'No series — everything shown unchecked. Select what you have.':'Pre-checked by series (current=L1, prev=L3, 2-back=L5). Dashed = future/store item.';
  document.getElementById('comp-hint').textContent=noSeries?'Check the components you own and set their levels.':'Solid = available by series. Dashed = future/store item.';
  buildDrivers(sNum);buildComponents(sNum);updateBoosts();
}

function makeDriverCard(name,rar,ds,lv,available,noSeries){
  const checked=!noSeries&&available;
  const item=document.createElement('div');
  item.className='driver-item'+(checked?' checked':(!available&&!noSeries?' store':''));
  item.dataset.driver=name;item.dataset.rarity=rar;
  const cb=document.createElement('input');cb.type='checkbox';if(checked)cb.checked=true;
  cb.onclick=e=>e.stopPropagation();cb.addEventListener('change',e=>item.classList.toggle('checked',e.target.checked));
  const main=document.createElement('div');main.className='card-main';
  const top=document.createElement('div');top.className='driver-top';
  const nm=document.createElement('span');nm.className='driver-name';nm.textContent=name;
  top.appendChild(cb);top.appendChild(nm);
  const meta=document.createElement('span');meta.className='card-meta'+(!available&&!noSeries?' store-tag':'');
  meta.textContent=`${rar} · S${ds}`+(!available&&!noSeries?' · store':'');
  const lvr=document.createElement('div');lvr.className='lv-row';
  const lvi=document.createElement('input');lvi.type='number';lvi.className='lv-inp';lvi.min=1;lvi.max=MAX_LV[rar];lvi.value=lv||1;
  lvi.onclick=e=>e.stopPropagation();lvi.oninput=e=>e.stopPropagation();
  lvr.innerHTML='<span class="lv-lbl">Lv</span>';lvr.appendChild(lvi);
  main.appendChild(top);main.appendChild(meta);main.appendChild(lvr);
  item.appendChild(main);item.appendChild(makeDials());
  item.addEventListener('click',e=>{if(e.target.tagName==='INPUT'||e.target.classList.contains('dial'))return;cb.checked=!cb.checked;item.classList.toggle('checked',cb.checked);});
  return item;
}

function buildDrivers(sNum){
  const tabsEl=document.getElementById('rar-tabs'),panelsEl=document.getElementById('rar-panels');
  tabsEl.innerHTML='';panelsEl.innerHTML='';const noSeries=sNum===null;
  RARITIES.forEach((rar,idx)=>{
    const tab=document.createElement('button');tab.className='rar-tab'+(idx===0?' active':'');tab.textContent=rar;
    const pid='panel-'+rar;
    tab.onclick=()=>{document.querySelectorAll('.rar-tab').forEach(t=>t.classList.remove('active'));document.querySelectorAll('.rar-panel').forEach(p=>p.classList.remove('active'));tab.classList.add('active');document.getElementById(pid).classList.add('active');};
    tabsEl.appendChild(tab);
    const panel=document.createElement('div');panel.className='rar-panel'+(idx===0?' active':'');panel.id=pid;
    const gid='dgrid-'+rar;panel.appendChild(makeHeader(rar+' drivers',gid));
    const grid=document.createElement('div');grid.className='driver-grid';grid.id=gid;
    DRIVER_SERIES[rar].forEach(([name,ds])=>{const lv=noSeries?1:defLv(ds,sNum);const av=noSeries?true:(lv!==null);grid.appendChild(makeDriverCard(name,rar,ds,lv||1,av,noSeries));});
    panel.appendChild(grid);panelsEl.appendChild(panel);
  });
  const legTab=document.createElement('button');legTab.className='rar-tab';legTab.textContent='Legendary';
  legTab.onclick=()=>{document.querySelectorAll('.rar-tab').forEach(t=>t.classList.remove('active'));document.querySelectorAll('.rar-panel').forEach(p=>p.classList.remove('active'));legTab.classList.add('active');document.getElementById('panel-Legendary').classList.add('active');};
  tabsEl.appendChild(legTab);
  const legPanel=document.createElement('div');legPanel.className='rar-panel';legPanel.id='panel-Legendary';
  legPanel.innerHTML=`<p class="hint" style="margin-bottom:8px">Not assumed — add the legendary drivers you own.</p><div class="leg-add-row"><div class="field"><span class="field-label">Driver</span><select id="leg-select"><option value="">Select legendary...</option>${LEGENDARY_ALL.map(n=>`<option>${n}</option>`).join('')}</select></div><div class="field"><span class="field-label">Level</span><input class="lv-inp" type="number" id="leg-lv" min="1" max="7" value="3" style="height:34px;width:48px;font-size:13px"></div><button class="add-btn" onclick="addLegendary()">+ Add</button></div><div class="leg-grid" id="leg-grid"></div>`;
  panelsEl.appendChild(legPanel);
}

function addLegendary(){
  const sel=document.getElementById('leg-select'),lv=parseInt(document.getElementById('leg-lv').value),name=sel.value;
  if(!name){alert('Select a legendary driver.');return;}
  if(document.querySelector(`[data-leg="${name}"]`)){alert(`${name} already added.`);return;}
  const item=document.createElement('div');item.className='leg-item';item.dataset.leg=name;item.dataset.lv=lv;
  const main=document.createElement('div');main.className='card-main';
  const top=document.createElement('div');top.className='leg-top';
  const nm=document.createElement('span');nm.className='leg-name';nm.textContent=name;
  const rm=document.createElement('button');rm.className='rm-btn';rm.textContent='✕';rm.onclick=e=>{e.stopPropagation();item.remove();};
  top.appendChild(nm);top.appendChild(rm);const sub=document.createElement('span');sub.className='leg-sub';sub.textContent=`Legendary · L${lv}`;
  main.appendChild(top);main.appendChild(sub);item.appendChild(main);item.appendChild(makeDials());
  document.getElementById('leg-grid').appendChild(item);sel.value='';document.getElementById('leg-lv').value=3;
}

function buildComponents(sNum){
  const container=document.getElementById('comp-slots');container.innerHTML='';const noSeries=sNum===null;
  Object.entries(COMP_SERIES).forEach(([slot,items])=>{
    const block=document.createElement('div');block.className='slot-block';
    const gid='cgrid-'+slot.replace(/\s/g,'-');block.appendChild(makeHeader(slot,gid));
    const grid=document.createElement('div');grid.className='comp-grid';grid.id=gid;
    items.forEach(([comp,cs])=>{
      const lv=noSeries?1:defLv(cs,sNum);const av=noSeries?true:(lv!==null);const checked=!noSeries&&av;
      const item=document.createElement('div');item.className='comp-item'+(checked?' checked':(!av&&!noSeries?' store':''));item.dataset.slot=slot;item.dataset.comp=comp;
      const cb=document.createElement('input');cb.type='checkbox';cb.className='comp-cb';if(checked)cb.checked=true;
      cb.onclick=e=>e.stopPropagation();cb.addEventListener('change',e=>item.classList.toggle('checked',e.target.checked));
      const main=document.createElement('div');main.className='card-main';
      const nm=document.createElement('span');nm.className='comp-name';nm.textContent=comp;
      const meta=document.createElement('span');meta.className='card-meta'+(!av&&!noSeries?' store-tag':'');meta.textContent=`S${cs}`+(!av&&!noSeries?' · store':'');
      const lvr=document.createElement('div');lvr.className='lv-row';const lvi=document.createElement('input');lvi.type='number';lvi.className='lv-inp';lvi.min=1;lvi.max=11;lvi.value=lv||1;
      lvi.onclick=e=>e.stopPropagation();lvi.oninput=e=>e.stopPropagation();lvr.innerHTML='<span class="lv-lbl">Lv</span>';lvr.appendChild(lvi);
      main.appendChild(nm);main.appendChild(meta);main.appendChild(lvr);item.appendChild(cb);item.appendChild(main);item.appendChild(makeDials());
      item.addEventListener('click',e=>{if(e.target.tagName==='INPUT'||e.target.classList.contains('dial'))return;cb.checked=!cb.checked;item.classList.toggle('checked',cb.checked);});
      grid.appendChild(item);
    });
    block.appendChild(grid);container.appendChild(block);
  });
}

function getBoost(el){if(el.querySelector('.dial[data-n="20"].on-20'))return 20;if(el.querySelector('.dial[data-n="10"].on-10'))return 10;return 0;}

function submitForm(){
  const series=document.getElementById('series').value;
  if(!series){alert('Please select a series or "No series".');return;}
  const track=document.getElementById('track').value,need=document.getElementById('need').value;
  const checkedBoosts=[];
  document.querySelectorAll('.boost-item input:checked').forEach(cb=>{checkedBoosts.push(cb.closest('.boost-item').querySelector('.boost-name').textContent);});
  const drivers=[];
  document.querySelectorAll('.driver-item.checked').forEach(item=>{const lv=item.querySelector('.lv-inp').value,b=getBoost(item);drivers.push(`${item.dataset.driver} ${item.dataset.rarity} L${lv}${b?` [GP+${b}%]`:''}`);});
  document.querySelectorAll('.leg-item').forEach(item=>{const b=getBoost(item);drivers.push(`${item.dataset.leg} Legendary L${item.dataset.lv}${b?` [GP+${b}%]`:''}`);});
  if(!drivers.length){alert('Please add at least one driver.');return;}
  const comps=[];
  document.querySelectorAll('.comp-item.checked').forEach(item=>{const lv=item.querySelector('.lv-inp').value,b=getBoost(item);comps.push(`${item.dataset.slot}: ${item.dataset.comp} L${lv}${b?` [GP+${b}%]`:''}`);});
  if(!comps.length){alert('Please select at least one component.');return;}
  const needMap={setup:'best setup',upgrade:'upgrade advice',both:'best setup and upgrade advice'};
  const seriesStr=series==='0'?'No specific series':`Series: ${series}`;
  const trackStr=track?`Track: ${track}`:(series==='0'?'No specific track':'all tracks in this series');
  const hasGP=drivers.some(d=>d.includes('[GP'))||comps.some(c=>c.includes('[GP'));
  const gpNote=hasGP?' GP boost active: multiply ALL stats of boosted items by 1.10 or 1.20 before scoring.':'';
  const msg=[`${seriesStr}. ${trackStr}. Need: ${needMap[need]}.${gpNote}`,`Drivers: ${drivers.join(', ')}.`,`Components: ${comps.join(' | ')}.`,checkedBoosts.length?`Boosts available: ${checkedBoosts.join(', ')}.`:''].filter(Boolean).join(' ');
  navigator.clipboard.writeText(msg).then(()=>{const btn=document.querySelector('.submit-btn');btn.textContent='✅ Copied! Paste into Claude';btn.style.background='#16a34a';setTimeout(()=>{btn.textContent='Get my recommendation ↗';btn.style.background='#111';},3000);}).catch(()=>{prompt('Copy this and paste into Claude:',msg);});
}
</script>
</body>
</html>
```

---

## Step 1: Player Onboarding

When a player first asks for help, gather this information conversationally — don't dump all questions at once. Ask 2–3 at a time and follow the natural flow.

### Required Info
- **Current series** (1–12)
- **Drivers they own** — for each driver: name, **rarity** (Common / Rare / Epic / Legendary), and current level
- **Components they have** (by in-game name) + the level each is upgraded to
- **What they need help with**: track-specific setup, general upgrade advice, or both

### Optional / Contextual
- **Specific track** they're preparing for (if setup help is needed)
- **Resources available** (coins, bux) — useful for upgrade prioritization
- **Next series they're targeting** — useful for forward-looking upgrade advice

### Sample Opening Flow
> "Let's get your setup dialed in. Which series are you currently playing in?"
> *(After answer)*
> "Got it. Which drivers do you have, and what level is each one at?"
> *(After answer)*
> "And what components are you running? List each one by its in-game name and the level it's at."

---

## Step 2: Track Setup Recommendation

### 2a. Identify Track Stat Priorities

**First, determine if this is a single-track or full-series request.**

#### Single track request
- Load `references/tracks.md` and find the specific track
- Use its 1st Stat and 2nd Stat as direct priorities
- Optimize purely for those two stats

#### Full series request (no specific track chosen)
This is the most important case. Players CANNOT change their setup between races once inside a series — a setup optimized for one track will hurt them on others.

Follow this balancing logic:
1. Load all tracks for the player's current series from `references/tracks.md`
2. Tally how often each stat appears as 1st or 2nd priority across all series tracks
3. Identify the **lock stat** — any stat that appears on ALL or most tracks (always prioritized in setup)
4. Identify **conflicting stats** — where tracks split between different secondary needs (e.g. 3 tracks need Cornering, 1 needs Speed)
5. For conflicting stats: do NOT go all-in on the majority stat. Recommend components with respectable values across BOTH conflicting stats rather than maxing one at the expense of the other
6. Always explain the tradeoff clearly to the player, for example:

> "Race Start appears on all 4 tracks — that's your lock. Cornering dominates 3 tracks but Singapore demands Speed. Going pure Cornering means you'll lose Singapore badly, so I'm recommending a balanced setup that respects both."

**Series balance reference:**
- Series 3: Tyre Management lock (all 4) → Speed×2, Cornering×1, Power Unit×1 → balance SPD/CRN/PWR
- Series 6: Defending lock (all 4) → Speed×2, Power Unit×1, Cornering×1 → balance SPD/PWR/CRN
- Series 7: Race Start lock (all 4) → Cornering×3, Speed×1 → balance CRN/SPD, never sacrifice Speed entirely
- Series 9: Mix of Defending and Tyre Management → find components strong in both
- Apply same logic to any series — always tally first, then balance

### 2b. Select Best Components
- Load `references/components.md`
- For each of the 7 component slots, look up the player's component by name and level
- **Single track:** pick the component that best covers the track's 1st and 2nd stat
- **Full series (balanced):** pick the component with the best combined value across the lock stat AND the conflicting stats — avoid components that are extreme in one stat but zero in others
- Flag slots where the player's available options are a poor fit for the series balance needs

#### ⚠️ Battery Slot — Special Scoring Rule
The Battery slot is ALWAYS scored differently from the other 6 slots. It has unique overtake stats (OVT, IMP, DUR, RCH) that directly affect in-race performance and must be included in the score.

**Standard Battery scoring (all tracks):**
`Score = SPD + CRN (per series balance) + OVT + IMP`

**Overtake-priority tracks** (where Overtaking is the 1st stat — Sao Paulo, Hungaroring, Miami, Las Vegas, Spa, Abu Dhabi):
`Score = (OVT × 2) + (IMP × 2) + SPD + CRN`

**Sustained overtaking consideration:** When OVT scores are close between batteries, factor in DUR (Duration) and RCH (Recharge) as tiebreakers:
- Higher DUR = overtake mode lasts longer per use
- Higher RCH = overtake mode recharges faster
- Flag this to the player: *"Charge Core hits harder per overtake; Energy Reserve gives you more consistent overtake availability throughout the race."*

Never score the Battery slot using only SPD and CRN — always include OVT and IMP at minimum.

### 2c. Select Best Driver Pair
- Load the relevant series driver reference file
- Score each driver the player owns against the track's stat priorities (at their current level)
- Recommend the **2 drivers** whose combined stats best complement the chosen components for that track
- Briefly explain why (e.g., "Russell adds strong Speed and Cornering which this track rewards heavily")

### 2d. Output Format
Present the recommendation clearly:

```
🏁 TRACK: [Track Name]
📊 TRACK NEEDS: [Primary stat] → [Secondary stat] → [Tertiary stat]

🔧 RECOMMENDED SETUP:
  Brakes:      [Component Name] (Lv X) — covers [stat]
  Gearbox:     [Component Name] (Lv X) — covers [stat]
  Rear Wing:   [Component Name] (Lv X) — covers [stat]
  Front Wing:  [Component Name] (Lv X) — covers [stat]
  Suspension:  [Component Name] (Lv X) — covers [stat]
  Engine:      [Component Name] (Lv X) — covers [stat]
  DRS:         [Component Name] (Lv X) — covers [stat]

👤 RECOMMENDED DRIVERS:
  Driver 1: [Name] (Lv X) — [why they fit this track]
  Driver 2: [Name] (Lv X) — [why they fit this track]

💡 TIP: [Any notable weakness in setup or alternative to consider]
```

---

## Step 3: Upgrade Recommendations

### Logic
Upgrade suggestions should look **forward** — toward the next series the player is progressing to, not backward.

Priority order for upgrade advice:
1. Components that cover stats heavily demanded in the **next series' tracks**
2. The player's **primary driver pair** — upgrade them before investing in bench drivers
3. Plug the biggest gap — if one stat is consistently weak across multiple upcoming tracks, target components/drivers that address it

### How to Determine "Next Series" Needs
- Load `references/tracks.md` for the player's next series
- Identify the most common stat demands across those tracks
- Map those to the component slots and driver stats that cover them

### Output Format
```
⬆️ UPGRADE PRIORITY for [Player's Current Series → Next Series]:

  1. [Component/Driver Name] — currently Lv X, next series demands [stat] heavily
  2. [Component/Driver Name] — [reason]
  3. [Component/Driver Name] — [reason]

💰 If resources are limited: focus on #1 first — it gives you the biggest gain.
```

---

## Handling Missing Data

### Component not in reference files yet
> "I don't have the stat table for [Component Name] yet — that data is still being added. Based on the component type ([slot]), I'd generally recommend it for [stat] if you can confirm it focuses on that. Once the full tables are loaded, I can give you a precise answer."

### Series not yet in reference files
> "Full data for Series [X] is still being added. I can give you general advice based on the series progression pattern and what I know about the game. Your recommendation will sharpen once the data is loaded."

### Player has unusual or unknown component names
> Ask: "Can you double-check the exact in-game name? Some components have very similar names and I want to make sure I'm looking at the right stat table."

---

## Important Game Rules to Always Apply
- A player fields **exactly 2 drivers** per race — always recommend a pair, not a single driver
- Components have **7 slots** — always address all 7 in a full setup recommendation
- Higher level always beats lower level for the same component (no exceptions)
- A weaker component at a much higher level can outperform a stronger component at a low level — always factor in actual current stats, not just component type
- Driver level matters just like component level — a lower-tier driver at a high level can outperform a higher-tier driver at a low level

---

## Tone & Style
- Speak like a knowledgeable teammate, not a robot
- Be direct — players want clear recommendations, not endless caveats
- When data is missing, be honest but still give the best advice possible
- Keep outputs scannable — use the formatted output blocks above
- If a player seems new, briefly explain the reasoning; if they seem experienced, keep it tight

---

## Boosts

Boosts are consumable items used during races that add temporary stat bonuses to 3 stats each. Load `references/boosts.md` when making setup recommendations.

Each boost adds points to exactly 3 stats. Point values are: 5, 10, 15, 20, or 25.

### Stat categories
**Driver stats** (benefit the driver pair): Overtaking, Defending, Race Start, Tyre Management, Qualifying
**Car stats** (benefit the car setup): Speed, Cornering, Power Unit, Pit Stop Time, Overtake Mode

### Boost scoring logic

**Step 1 — Calculate track-relevant score**
For each available boost, sum the points that match the track's 2 priority stats only. This is the meaningful setup improvement.

Example for Melbourne (Race Start + Cornering):
- Prince: DEF:10 + RST:20 + CRN:20 → track score = RST:20 + CRN:20 = **40**
- Cuppa: OVT:10 + RST:20 + CRN:20 → track score = RST:20 + CRN:20 = **40**
- Herald: OVT:10 + RST:25 + CRN:15 → track score = RST:25 + CRN:15 = **40**

**Step 2 — Use the 3rd stat as tiebreaker**
When two or more boosts have the same track-relevant score, look at the 3rd stat and determine whether it benefits the driver or car:
- If it's a **driver stat** → compare to what the player's driver pair needs most (e.g. low Defending → pick Prince, low Overtaking → pick Cuppa)
- If it's a **car stat** → compare to what the player's car setup is weakest in for that track

Always explain the tiebreaker clearly:
*"Prince and Cuppa both add 40 points to Race Start and Cornering. Prince's extra 10 goes to Defending — better if your drivers are weak on defense. Cuppa's extra 10 goes to Overtaking — better if you need more passing ability."*

**Step 3 — Recommend up to 3 boosts**
Rank all available boosts by track-relevant score, apply tiebreaker where needed, and recommend the top options.

### Output format
```
🚀 RECOMMENDED BOOSTS:
  1. [Boost Name] — RST:20 + CRN:20 = 40 track points (extra: DEF:10 — useful if your drivers need defending)
  2. [Boost Name] — RST:20 + CRN:20 = 40 track points (extra: OVT:10 — useful for overtaking)
  💡 Alternatives if you don't have these: [list]
```

### When player hasn't listed boosts
Give generic recommendations based on track stats: *"For Melbourne I'd look for boosts that cover Race Start and Cornering. Top options are Prince, Cuppa, Herald, and Kawaii — all give 40 points to your priority stats."*

---

## Advanced Strategy Considerations

This skill is a **strategic starting point and reference**, not a win calculator. The game is managed by the player in real time — a good setup gives your car the best possible foundation to compete, but outcomes depend on in-race decisions.

### The "No Exploitable Gaps" Rule

Winning the primary stat matchup is the goal, but a large weakness in any secondary stat can cancel out a primary stat advantage. Think in terms of **margins**:

- You lead Cornering by 5 points → opponent's Power Unit advantage of 20 points likely cancels that out
- You lead Cornering by 15 points → a 5 point Power Unit deficit probably doesn't matter

**What to flag:** After selecting the primary stat setup, scan the player's total stats across all components and drivers. If any stat is significantly below the series norm — even a non-priority stat — flag it as a potential exploitable weakness. A good setup doesn't have to be perfect everywhere, but it shouldn't have a critical gap that hands opponents an easy advantage.

**How to frame it:** Don't just recommend the best setup — explain the tradeoffs. Tell the player where they're strong, where they're acceptable, and where they have a gap worth being aware of.

### Pit Stop Time

Pit stop time (PIT stat on components) is a valid strategic consideration but **not a primary driver of setup decisions**. Apply this logic:

- If two components are otherwise comparable in their primary stats, recommend the one with better PIT time
- Only suggest sacrificing meaningful primary stats for PIT improvement when the PIT difference is significant (roughly 0.15+ seconds across the full setup)
- Flag PIT as a tiebreaker consideration, not a core priority: *"Both options are close on Cornering — the Scramble also gives you a faster pit stop, so it's the pick here."*
- Some players do prioritize pit stop time as a personal strategy — if a player asks specifically about pit optimization, treat PIT as a primary stat for that request

### Battery Strategy

The Battery slot has unique overtake stats (OVT, IMP, DUR, RCH) that should be matched to the race situation:

- **Overtake-heavy tracks** (high Overtaking priority) → prioritize **OVT** (Overtake Modifier) and **IMP** (Impact) — how powerful and impactful each overtake attempt is
- **Longer/tactical races** → prioritize **DUR** (Duration) and **RCH** (Recharge) — sustain overtake capability throughout the race rather than burning it early
- **When it's close** → Spare Pack and Energy Reserve lead on sustained use; Charge Core leads on raw OVT power but recharges slower
- Always note the tradeoff: *"Charge Core gives you the strongest single overtake attempt but recharges slower — better for one decisive move. Energy Reserve gives you more consistent overtake availability throughout the race."*

### Overall Philosophy

Every stat matters in every race — the track priorities tell you where to focus, not what to ignore. A player with 100 Cornering points but only 70 Power Unit can still lose to an opponent with 95 Cornering and 90 Power Unit because the Power Unit gap is large enough to offset the Cornering lead. The goal is to:

1. **Win or match the primary stat** — this is the foundation
2. **Stay competitive in secondary stats** — no gap larger than ~15-20 points if avoidable
3. **Use PIT and Battery to gain edges** when primary stats are otherwise matched
4. **Explain the tradeoffs** so the player understands their setup and can make smart in-race decisions

---

## GP Boost Considerations

During GP races, certain drivers and components receive a temporary stat boost of 10% or 20%. These boosts can be significant enough to justify switching a driver or component that wouldn't otherwise be the top pick.

### How to apply GP boosts
When a player indicates a driver or component has a GP boost, apply the boost to ALL of that driver's or component's stats before scoring:
- **10% boost**: multiply all stats by 1.10
- **20% boost**: multiply all stats by 1.20

Then re-run the normal setup recommendation with the boosted values. A boosted driver or component may now outscore options that would normally rank higher.

### When a boost changes the recommendation
- If a boosted driver now has the highest Race Start (or whatever the lock stat is), recommend them even if they wouldn't normally be the pick
- If a boosted component now leads its slot for the priority stats, flag it: "The 20% boost on Scramble pushes its Speed to X and Cornering to Y — it's now the strongest Brakes option for this setup."
- Always note that the boost is temporary and the recommendation may differ in non-GP races

### Car-first rule still applies
Even with GP boosts, components take priority. A 20% boost on a component is generally more impactful than a 20% boost on a driver, because car setup is the foundation.

Confirmed GP boost rules:
- Boost applies to ALL stats of the driver or component (not just one stat)
- Multiple drivers and components can be boosted simultaneously in the same GP
- Boost is always either 10% or 20% — no other values
